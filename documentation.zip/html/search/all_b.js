var searchData=
[
  ['tostring',['toString',['../class_astronomical_object.html#a5222e776b5e8edeff8ffdbb500e7262c',1,'AstronomicalObject::toString()'],['../class_cosmic_void.html#afa0cccf5c727de925cb9179fb195016d',1,'CosmicVoid::toString()'],['../class_galaxy.html#acee9819da1e7e92ada5aa74d8ed49556',1,'Galaxy::toString()'],['../class_spiral_galaxy.html#ace12ff1f2678a5eb40ee02acad1d9207',1,'SpiralGalaxy::toString()']]]
];
