var searchData=
[
  ['sol',['sol',['../class_galaxy.html#af6a345bb37893320149e504523a8cf86',1,'Galaxy']]],
  ['star_5fcount',['star_count',['../class_astronomical_object.html#acd7973e0eb58160d3bf0f9f0d70c2768',1,'AstronomicalObject']]]
];
