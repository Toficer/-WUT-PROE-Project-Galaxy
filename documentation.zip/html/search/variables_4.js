var searchData=
[
  ['proxima_5fcentauri',['Proxima_Centauri',['../class_galaxy.html#a417192e5bb58518a2e94fdcd24d16bda',1,'Galaxy']]]
];
