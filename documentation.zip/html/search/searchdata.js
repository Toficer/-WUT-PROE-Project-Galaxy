var indexSectionsWithContent =
{
  0: "acdgimnoprstw~",
  1: "acgmps",
  2: "acgmps",
  3: "acgmoprstw~",
  4: "dginps",
  5: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "related"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Friends"
};

