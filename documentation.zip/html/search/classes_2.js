var searchData=
[
  ['galaxy',['Galaxy',['../class_galaxy.html',1,'']]]
];
