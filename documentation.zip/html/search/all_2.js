var searchData=
[
  ['dettype',['detType',['../class_astronomical_object.html#ade5ca002722b6d463d412743f85591fb',1,'AstronomicalObject::detType()'],['../class_cosmic_void.html#a7aed110b830e5bb326669c3e149a1b62',1,'CosmicVoid::detType()'],['../class_galaxy.html#abd5fb14480ee6c66d827e5c76d9a926c',1,'Galaxy::detType()'],['../class_spiral_galaxy.html#a8d052c4bbe59e783a957d84f1180b1ec',1,'SpiralGalaxy::detType()']]]
];
