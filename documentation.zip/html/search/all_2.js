var searchData=
[
  ['diameter_5fly',['diameter_ly',['../class_astronomical_object.html#a507311a9f916293ed9e44ef5a788c9ae',1,'AstronomicalObject']]]
];
