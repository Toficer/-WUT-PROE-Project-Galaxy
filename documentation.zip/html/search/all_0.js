var searchData=
[
  ['astronomicalobject',['AstronomicalObject',['../class_astronomical_object.html',1,'AstronomicalObject'],['../class_astronomical_object.html#ad79703d1a1fc538f8e10d3ffae7874c0',1,'AstronomicalObject::AstronomicalObject()']]]
];
