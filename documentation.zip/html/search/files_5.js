var searchData=
[
  ['spiralgalaxy_2ecpp',['SpiralGalaxy.cpp',['../_spiral_galaxy_8cpp.html',1,'']]],
  ['spiralgalaxy_2eh',['SpiralGalaxy.h',['../_spiral_galaxy_8h.html',1,'']]],
  ['star_2ecpp',['Star.cpp',['../_star_8cpp.html',1,'']]],
  ['star_2eh',['Star.h',['../_star_8h.html',1,'']]]
];
