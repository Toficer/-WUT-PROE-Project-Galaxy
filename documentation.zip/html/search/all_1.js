var searchData=
[
  ['cosmicvoid',['CosmicVoid',['../class_cosmic_void.html',1,'CosmicVoid'],['../class_cosmic_void.html#aca6905b73348b9691dfe36659ae84a7f',1,'CosmicVoid::CosmicVoid(bool alien_presence=0)'],['../class_cosmic_void.html#ae29abd317da85f74e7bb73b6bd3ed64a',1,'CosmicVoid::CosmicVoid(const CosmicVoid &amp;c)']]]
];
