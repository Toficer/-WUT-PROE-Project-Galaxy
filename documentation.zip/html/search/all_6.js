var searchData=
[
  ['number_5fof_5farms',['number_of_arms',['../class_spiral_galaxy.html#a9d4d0d5904367ffe59dcab0eed215acf',1,'SpiralGalaxy']]]
];
