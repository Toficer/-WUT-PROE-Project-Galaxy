var searchData=
[
  ['_7egalaxy',['~Galaxy',['../class_galaxy.html#a4b82609ee64e4e6c65633c1f840bd517',1,'Galaxy']]],
  ['_7emoon',['~Moon',['../class_moon.html#a3c2a0d46f278ee7ecf924c4a31da15f1',1,'Moon']]],
  ['_7eplanet',['~Planet',['../class_planet.html#aaa1aaed9d4ef90b4836531edb7b18e0a',1,'Planet']]],
  ['_7estar',['~Star',['../class_star.html#ac20a90b97d0201576e05aefef2418b94',1,'Star']]]
];
