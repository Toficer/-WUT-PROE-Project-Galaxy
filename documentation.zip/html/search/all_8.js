var searchData=
[
  ['planet',['Planet',['../class_planet.html',1,'Planet'],['../class_planet.html#ac88200b337a62e1377858e3116f9412b',1,'Planet::Planet()'],['../class_planet.html#aa86a3442cc5513995446f4566aece275',1,'Planet::Planet(const Planet &amp;p)']]],
  ['planet_2ecpp',['Planet.cpp',['../_planet_8cpp.html',1,'']]],
  ['planet_2eh',['Planet.h',['../_planet_8h.html',1,'']]],
  ['projectgalaxy_2ecpp',['ProjectGalaxy.cpp',['../_project_galaxy_8cpp.html',1,'']]],
  ['proxima_5fcentauri',['Proxima_Centauri',['../class_galaxy.html#a417192e5bb58518a2e94fdcd24d16bda',1,'Galaxy']]]
];
