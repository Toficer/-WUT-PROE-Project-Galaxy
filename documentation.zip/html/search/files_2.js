var searchData=
[
  ['galaxy_2ecpp',['Galaxy.cpp',['../_galaxy_8cpp.html',1,'']]],
  ['galaxy_2eh',['Galaxy.h',['../_galaxy_8h.html',1,'']]]
];
