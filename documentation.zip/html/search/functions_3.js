var searchData=
[
  ['galaxy',['Galaxy',['../class_galaxy.html#a70706b5c9ef38761321c43991cb3c8cc',1,'Galaxy::Galaxy(int diameter_ly=150000, int star_count=317000, int galaxy_age=13700)'],['../class_galaxy.html#a00b8ba532ba4fc395474e0a05323216d',1,'Galaxy::Galaxy(const Galaxy &amp;g)']]]
];
