var searchData=
[
  ['readstring',['readString',['../class_astronomical_object.html#a7d00828abdd97d2c74fffb72bed4591c',1,'AstronomicalObject::readString()'],['../class_cosmic_void.html#a5d9cc97e5dd76315e10a8335e3e5e3aa',1,'CosmicVoid::readString()'],['../class_galaxy.html#aa5cb8f2b845372007d3c2604c442d5ed',1,'Galaxy::readString()'],['../class_spiral_galaxy.html#a0c72a940cf32516a70a624583218fe01',1,'SpiralGalaxy::readString()']]],
  ['returndiameter',['returnDiameter',['../class_moon.html#a2b1dd4e22dc9317ae05e36340d622019',1,'Moon::returnDiameter()'],['../class_planet.html#a018a7008f1d94bd18557677a552bf58c',1,'Planet::returnDiameter()']]]
];
