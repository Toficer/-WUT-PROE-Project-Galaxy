var searchData=
[
  ['cosmicvoid',['CosmicVoid',['../class_cosmic_void.html#a7f59948e9b2e59e12748c8bc16c41067',1,'CosmicVoid::CosmicVoid()'],['../class_cosmic_void.html#ae29abd317da85f74e7bb73b6bd3ed64a',1,'CosmicVoid::CosmicVoid(const CosmicVoid &amp;c)']]],
  ['countgalaxies',['countGalaxies',['../class_galaxy.html#a9f954d505f4a155f4173f4fe06c01397',1,'Galaxy']]]
];
