var searchData=
[
  ['galaxy_5fage',['galaxy_age',['../class_galaxy.html#a8d205699ad0002e81a6c9055b8471c61',1,'Galaxy']]],
  ['galaxy_5fcount',['galaxy_count',['../class_galaxy.html#a3360a1feb0a53a1603425c3e0b0ad85b',1,'Galaxy']]]
];
