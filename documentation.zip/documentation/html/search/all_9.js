var searchData=
[
  ['returndiameter',['returnDiameter',['../class_moon.html#a2b1dd4e22dc9317ae05e36340d622019',1,'Moon::returnDiameter()'],['../class_planet.html#a018a7008f1d94bd18557677a552bf58c',1,'Planet::returnDiameter()']]]
];
