var searchData=
[
  ['spiralgalaxy',['SpiralGalaxy',['../class_spiral_galaxy.html',1,'']]],
  ['star',['Star',['../class_star.html',1,'']]]
];
