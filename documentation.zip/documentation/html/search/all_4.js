var searchData=
[
  ['inhabited_5fplanet',['inhabited_planet',['../class_galaxy.html#a2412721b7f390bf7b5863a06dd277d35',1,'Galaxy']]],
  ['interesting_5fmoon',['interesting_moon',['../class_galaxy.html#a9b9d5ff839ca8edf2319be2bd3e92e4d',1,'Galaxy']]]
];
