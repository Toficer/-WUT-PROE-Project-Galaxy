var searchData=
[
  ['spiralgalaxy',['SpiralGalaxy',['../class_spiral_galaxy.html#a5408c0e138f6b3bc9a585c63da4980c3',1,'SpiralGalaxy::SpiralGalaxy()'],['../class_spiral_galaxy.html#a6c5819460c8f25d5526b6d89421e438c',1,'SpiralGalaxy::SpiralGalaxy(const SpiralGalaxy &amp;sg)']]],
  ['star',['Star',['../class_star.html#ac174c691c269196c47324a13c3c9f903',1,'Star::Star()'],['../class_star.html#aad89e543ed339082b989e2c1a729275d',1,'Star::Star(const Star &amp;s)']]]
];
