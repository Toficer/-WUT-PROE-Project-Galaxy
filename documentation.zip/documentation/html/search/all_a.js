var searchData=
[
  ['sol',['sol',['../class_galaxy.html#af6a345bb37893320149e504523a8cf86',1,'Galaxy']]],
  ['spiralgalaxy',['SpiralGalaxy',['../class_spiral_galaxy.html',1,'SpiralGalaxy'],['../class_spiral_galaxy.html#a5408c0e138f6b3bc9a585c63da4980c3',1,'SpiralGalaxy::SpiralGalaxy()'],['../class_spiral_galaxy.html#a6c5819460c8f25d5526b6d89421e438c',1,'SpiralGalaxy::SpiralGalaxy(const SpiralGalaxy &amp;sg)']]],
  ['spiralgalaxy_2ecpp',['SpiralGalaxy.cpp',['../_spiral_galaxy_8cpp.html',1,'']]],
  ['spiralgalaxy_2eh',['SpiralGalaxy.h',['../_spiral_galaxy_8h.html',1,'']]],
  ['star',['Star',['../class_star.html',1,'Star'],['../class_star.html#ac174c691c269196c47324a13c3c9f903',1,'Star::Star()'],['../class_star.html#aad89e543ed339082b989e2c1a729275d',1,'Star::Star(const Star &amp;s)']]],
  ['star_2ecpp',['Star.cpp',['../_star_8cpp.html',1,'']]],
  ['star_2eh',['Star.h',['../_star_8h.html',1,'']]],
  ['star_5fcount',['star_count',['../class_astronomical_object.html#acd7973e0eb58160d3bf0f9f0d70c2768',1,'AstronomicalObject']]]
];
