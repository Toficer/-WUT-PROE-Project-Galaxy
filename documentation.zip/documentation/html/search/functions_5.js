var searchData=
[
  ['planet',['Planet',['../class_planet.html#ac88200b337a62e1377858e3116f9412b',1,'Planet::Planet()'],['../class_planet.html#aa86a3442cc5513995446f4566aece275',1,'Planet::Planet(const Planet &amp;p)']]]
];
