var searchData=
[
  ['cosmicvoid',['CosmicVoid',['../class_cosmic_void.html',1,'']]]
];
