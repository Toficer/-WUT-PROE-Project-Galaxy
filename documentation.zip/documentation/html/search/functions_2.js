var searchData=
[
  ['galaxy',['Galaxy',['../class_galaxy.html#aac431eec66d158f5f82cdbc3eec39586',1,'Galaxy::Galaxy()'],['../class_galaxy.html#a00b8ba532ba4fc395474e0a05323216d',1,'Galaxy::Galaxy(const Galaxy &amp;g)']]]
];
