var searchData=
[
  ['cosmicvoid',['CosmicVoid',['../class_cosmic_void.html',1,'CosmicVoid'],['../class_cosmic_void.html#a7f59948e9b2e59e12748c8bc16c41067',1,'CosmicVoid::CosmicVoid()'],['../class_cosmic_void.html#ae29abd317da85f74e7bb73b6bd3ed64a',1,'CosmicVoid::CosmicVoid(const CosmicVoid &amp;c)']]],
  ['cosmicvoid_2ecpp',['CosmicVoid.cpp',['../_cosmic_void_8cpp.html',1,'']]],
  ['cosmicvoid_2eh',['CosmicVoid.h',['../_cosmic_void_8h.html',1,'']]],
  ['countgalaxies',['countGalaxies',['../class_galaxy.html#a9f954d505f4a155f4173f4fe06c01397',1,'Galaxy']]]
];
