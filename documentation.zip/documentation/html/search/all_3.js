var searchData=
[
  ['galaxy',['Galaxy',['../class_galaxy.html',1,'Galaxy'],['../class_galaxy.html#aac431eec66d158f5f82cdbc3eec39586',1,'Galaxy::Galaxy()'],['../class_galaxy.html#a00b8ba532ba4fc395474e0a05323216d',1,'Galaxy::Galaxy(const Galaxy &amp;g)']]],
  ['galaxy_2ecpp',['Galaxy.cpp',['../_galaxy_8cpp.html',1,'']]],
  ['galaxy_2eh',['Galaxy.h',['../_galaxy_8h.html',1,'']]],
  ['galaxy_5fage',['galaxy_age',['../class_galaxy.html#a8d205699ad0002e81a6c9055b8471c61',1,'Galaxy']]],
  ['galaxy_5fcount',['galaxy_count',['../class_galaxy.html#a3360a1feb0a53a1603425c3e0b0ad85b',1,'Galaxy']]]
];
